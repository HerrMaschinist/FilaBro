// Top-level build file where you can add configuration options common to all sub-projects/modules.

plugins {
    // Apply these plugins only to submodules, not here.
    id("com.android.application") version "8.1.0" apply false
    id("com.android.library") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.0" apply false
    id("org.jetbrains.kotlin.jvm") version "1.9.0" apply false
    id("org.jetbrains.kotlin.kapt") version "1.9.0" apply false
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}