package com.herrmaschinist.filabro.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import com.herrmaschinist.filabro.data.local.entity.FilamentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FilamentDao {
    @Query("SELECT * FROM filament_cache")
    fun getAll(): Flow<List<FilamentEntity>>

    @Query("DELETE FROM filament_cache")
    suspend fun clear()
}