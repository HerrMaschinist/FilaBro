package com.herrmaschinist.filabro.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Abbildung der lokal markierten Favoriten.
 */
@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val spoolId: Long
)