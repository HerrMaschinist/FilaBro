package com.herrmaschinist.filabro.data.repository

import com.herrmaschinist.filabro.data.local.SpoolDatabase
import com.herrmaschinist.filabro.data.local.entity.FavoriteEntity
import com.herrmaschinist.filabro.data.network.SpoolService
import com.herrmaschinist.filabro.data.network.model.UpdateSpoolRequest
import com.herrmaschinist.filabro.domain.model.Spool
import com.herrmaschinist.filabro.domain.repository.SpoolRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Konkrete Implementierung des [SpoolRepository].
 * Koordiniert Daten aus dem lokalen Cache und dem Netzwerk.
 */
class SpoolRepositoryImpl(
    private val api: SpoolService,
    private val db: SpoolDatabase,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : SpoolRepository {

    override fun getSpools(refresh: Boolean): Flow<List<Spool>> {
        // Wir liefern derzeit nur Daten aus dem Netzwerk und mappen sie direkt.
        // Die Cache‑Synchronisation wird später implementiert.
        val remote = fetchRemoteSpools(refresh)
        val favoritesFlow = db.favoriteDao().getAll()
        return remote.combine(favoritesFlow) { spools, favorites ->
            val favoriteIds = favorites.map { it.spoolId }.toSet()
            spools.map { spool ->
                if (favoriteIds.contains(spool.id)) {
                    spool.copy(notes = (spool.notes ?: "") + " [Fav]")
                } else spool
            }
        }
    }

    private fun fetchRemoteSpools(refresh: Boolean): Flow<List<Spool>> =
        kotlinx.coroutines.flow.flow {
            if (refresh) {
                val response = api.getSpools()
                val domainSpools = response.map { it.toDomain() }
                emit(domainSpools)
            } else {
                // Wenn nicht aktualisiert werden soll, geben wir leer zurück und vertrauen auf Cache.
                emit(emptyList())
            }
        }

    override suspend fun getSpoolById(id: Long, refresh: Boolean): Spool = withContext(ioDispatcher) {
        if (refresh) {
            api.getSpool(id).toDomain()
        } else {
            val entity = db.spoolDao().getById(id)
            // TODO: mapping vom Entity zum Domain‑Modell
            entity?.let {
                // Noch kein Mapping implementiert
                throw NotImplementedError("Mapping von SpoolEntity zu Domain fehlt")
            } ?: api.getSpool(id).toDomain()
        }
    }

    override suspend fun updateSpoolWeight(id: Long, remainingWeight: Float): Spool = withContext(ioDispatcher) {
        val dto = api.updateSpool(id, UpdateSpoolRequest(remainingWeight))
        dto.toDomain()
    }

    override suspend fun setFavorite(id: Long, favorite: Boolean) {
        withContext(ioDispatcher) {
            if (favorite) {
                db.favoriteDao().insertFavorite(FavoriteEntity(id))
            } else {
                db.favoriteDao().deleteFavorite(id)
            }
        }
    }
}