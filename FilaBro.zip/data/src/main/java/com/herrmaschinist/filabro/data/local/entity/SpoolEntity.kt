package com.herrmaschinist.filabro.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "spool_cache")
data class SpoolEntity(
    @PrimaryKey val id: Long,
    val filamentId: Long,
    val totalWeight: Float?,
    val emptyWeight: Float?,
    val remainingWeight: Float?,
    val name: String,
    val notes: String?
)