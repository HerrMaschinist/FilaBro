package com.herrmaschinist.filabro.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Transaction
import com.herrmaschinist.filabro.data.local.entity.SpoolEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SpoolDao {
    @Query("SELECT * FROM spool_cache")
    fun getAll(): Flow<List<SpoolEntity>>

    @Query("SELECT * FROM spool_cache WHERE id = :id")
    suspend fun getById(id: Long): SpoolEntity?

    @Query("DELETE FROM spool_cache")
    suspend fun clear()
}