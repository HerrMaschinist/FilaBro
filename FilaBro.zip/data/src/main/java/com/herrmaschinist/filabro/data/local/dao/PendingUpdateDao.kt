package com.herrmaschinist.filabro.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.herrmaschinist.filabro.data.local.entity.PendingUpdateEntity

@Dao
interface PendingUpdateDao {
    @Query("SELECT * FROM pending_updates")
    suspend fun getAll(): List<PendingUpdateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pendingUpdate: PendingUpdateEntity)

    @Query("DELETE FROM pending_updates WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("DELETE FROM pending_updates")
    suspend fun clear()
}