package com.herrmaschinist.filabro.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity zum Speichern von Offline‑Updates, die später synchronisiert werden sollen.
 */
@Entity(tableName = "pending_updates")
data class PendingUpdateEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val spoolId: Long,
    val remainingWeight: Float
)