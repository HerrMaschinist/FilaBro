package com.herrmaschinist.filabro.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "filament_cache")
data class FilamentEntity(
    @PrimaryKey val id: Long,
    val manufacturer: String,
    val material: String,
    val color: String,
    val density: Float?,
    val diameter: Float?
)