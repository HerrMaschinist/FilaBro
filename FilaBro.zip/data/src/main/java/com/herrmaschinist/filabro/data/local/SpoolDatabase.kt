package com.herrmaschinist.filabro.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.herrmaschinist.filabro.data.local.dao.FavoriteDao
import com.herrmaschinist.filabro.data.local.dao.FilamentDao
import com.herrmaschinist.filabro.data.local.dao.PendingUpdateDao
import com.herrmaschinist.filabro.data.local.dao.SpoolDao
import com.herrmaschinist.filabro.data.local.entity.FavoriteEntity
import com.herrmaschinist.filabro.data.local.entity.FilamentEntity
import com.herrmaschinist.filabro.data.local.entity.PendingUpdateEntity
import com.herrmaschinist.filabro.data.local.entity.SpoolEntity

@Database(
    entities = [SpoolEntity::class, FilamentEntity::class, FavoriteEntity::class, PendingUpdateEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SpoolDatabase : RoomDatabase() {
    abstract fun spoolDao(): SpoolDao
    abstract fun filamentDao(): FilamentDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun pendingUpdateDao(): PendingUpdateDao
}