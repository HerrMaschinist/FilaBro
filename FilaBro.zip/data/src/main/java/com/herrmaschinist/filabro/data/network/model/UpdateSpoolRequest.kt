package com.herrmaschinist.filabro.data.network.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class UpdateSpoolRequest(
    @Json(name = "remaining_weight") val remainingWeight: Float
)