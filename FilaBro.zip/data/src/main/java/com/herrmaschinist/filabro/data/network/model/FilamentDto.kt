package com.herrmaschinist.filabro.data.network.model

import com.herrmaschinist.filabro.domain.model.Filament
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class FilamentDto(
    @Json(name = "id") val id: Long,
    @Json(name = "brand") val brand: String?,
    @Json(name = "material") val material: String?,
    @Json(name = "color") val color: String?,
    @Json(name = "density") val density: Float?,
    @Json(name = "diameter") val diameter: Float?
) {
    fun toDomain(): Filament = Filament(
        id = id,
        manufacturer = brand ?: "",
        material = material ?: "",
        color = color ?: "",
        density = density,
        diameter = diameter
    )
}