package com.herrmaschinist.filabro.data.network

import com.herrmaschinist.filabro.data.network.model.SpoolDto
import com.herrmaschinist.filabro.data.network.model.UpdateSpoolRequest
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Retrofit‑Interface zur Kommunikation mit dem Spoolman‑Server.
 */
interface SpoolService {
    @GET("/api/v1/spool")
    suspend fun getSpools(
        @Query("expand[]") expand: String = "filament"
    ): List<SpoolDto>

    @GET("/api/v1/spool/{id}")
    suspend fun getSpool(
        @Path("id") id: Long,
        @Query("expand[]") expand: String = "filament"
    ): SpoolDto

    @PATCH("/api/v1/spool/{id}")
    suspend fun updateSpool(
        @Path("id") id: Long,
        @Body request: UpdateSpoolRequest
    ): SpoolDto
}