package com.herrmaschinist.filabro.data.network.model

import com.herrmaschinist.filabro.domain.model.Spool
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SpoolDto(
    @Json(name = "id") val id: Long,
    @Json(name = "filament") val filament: FilamentDto?,
    @Json(name = "total_weight") val totalWeight: Float?,
    @Json(name = "empty_weight") val emptyWeight: Float?,
    @Json(name = "remaining_weight") val remainingWeight: Float?,
    @Json(name = "name") val name: String?,
    @Json(name = "notes") val notes: String?
) {
    fun toDomain(): Spool = Spool(
        id = id,
        filament = filament?.toDomain() ?: throw IllegalStateException("Filament is required"),
        totalWeight = totalWeight,
        emptyWeight = emptyWeight,
        remainingWeight = remainingWeight,
        name = name ?: "",
        notes = notes
    )
}