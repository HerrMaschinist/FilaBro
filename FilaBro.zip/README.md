# FilaBro Android‑App

Dieses Projekt implementiert eine native Android‑Anwendung zur Verwaltung von 3D‑Druck‑Filamentspulen. Die App verbindet sich mit einer vorhandenen Spoolman‑Instanz und bietet Funktionen wie Favoriten, Kamera‑Scan, NFC‑Integration, Homescreen‑Widget und Offline‑Unterstützung.

## Aufbau

Das Repository ist nach Clean Architecture strukturiert und besteht aus drei Modulen:

- **app** – enthält die UI auf Basis von Jetpack Compose, die Aktivitäten und die Dependency Injection. Das Modul referenziert die Daten‑ und Domain‑Module.
- **domain** – definiert die Geschäftslogik, Domain‑Modelle, Repositories und Use Cases. Dieses Modul ist unabhängig von Android.
- **data** – implementiert die Repositories, Netzwerk‑ und Datenbankschichten. Enthält Retrofit‑Interfaces für die Spoolman‑API und Room‑Entities für den lokalen Cache.

## Setup

1. **Voraussetzungen:** Android Studio Flamingo oder neuer, Gradle 8.x, Android SDK 34. Kotlin 1.9 ist bereits konfiguriert.
2. **Klonen:** `git clone <repo-url>`
3. **Öffnen:** Projekt im Android Studio öffnen; Gradle‑Sync starten lassen.
4. **Server‑Konfiguration:** Die Spoolman‑Instanz muss unter der im Manifest gesetzten Standard‑URL erreichbar sein (z. B. `http://192.168.50.10:7912`). In der aktuellen Umsetzung wird die URL später über die Einstellungen anpassbar sein.
5. **Berechtigungen:** Die App benötigt Internet‑ und Kamerazugriff. NFC ist optional, wird aber im Manifest deklariert.

## Funktionsumfang (geplant)

Diese Version enthält lediglich den Projekt‑Skeleton. Die folgenden Features werden schrittweise implementiert:

1. Verbindungsmanagement mit Health‑Check und Speicherung der Server‑URL
2. Spulenliste mit Sortier‑/Filter‑Funktionen und Favoriten
3. Detailansicht mit Gewichtsanpassung, QR‑Code und NFC‑Schreiben
4. Scanner mit QR‑, NFC‑ und OCR‑Erkennung
5. Homescreen‑Widget für schnellen Zugriff auf Favoriten
6. Offline‑Fähigkeit mit Room und WorkManager
7. Einstellungen zur Konfiguration von URL, Theme und Backup

## Tests

Die Teststruktur ist vorbereitet, jedoch noch nicht gefüllt. Unit‑Tests für Use Cases und Repositories werden in den nächsten Schritten hinzugefügt.

## Lizenz

Dieses Projekt steht unter der MIT‑Lizenz.