plugins {
    id("org.jetbrains.kotlin.jvm")
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

dependencies {
    // Coroutines for domain logic
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
}