package com.herrmaschinist.filabro.domain.usecase

import com.herrmaschinist.filabro.domain.model.Spool
import com.herrmaschinist.filabro.domain.repository.SpoolRepository
import kotlinx.coroutines.flow.Flow

/**
 * Anwendungsfall zum Abrufen aller Spulen.
 */
class GetSpoolsUseCase(private val repository: SpoolRepository) {
    operator fun invoke(refresh: Boolean = false): Flow<List<Spool>> =
        repository.getSpools(refresh)
}