package com.herrmaschinist.filabro.domain.repository

import com.herrmaschinist.filabro.domain.model.Spool
import kotlinx.coroutines.flow.Flow

/**
 * Interface für den Zugriff auf Spulendaten aus verschiedenen Quellen (API, Cache).
 */
interface SpoolRepository {
    /** Gibt einen Datenstrom aller Spulen zurück, optional aus dem lokalen Cache. */
    fun getSpools(refresh: Boolean = false): Flow<List<Spool>>

    /** Holt eine einzelne Spule anhand ihrer ID. */
    suspend fun getSpoolById(id: Long, refresh: Boolean = false): Spool

    /** Aktualisiert das verbleibende Gewicht einer Spule. */
    suspend fun updateSpoolWeight(id: Long, remainingWeight: Float): Spool

    /** Setzt oder entfernt den Favoritenstatus lokal. */
    suspend fun setFavorite(id: Long, favorite: Boolean)
}