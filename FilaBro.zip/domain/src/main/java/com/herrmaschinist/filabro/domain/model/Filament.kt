package com.herrmaschinist.filabro.domain.model

/**
 * Domain‑Modell für ein Filament.
 */
data class Filament(
    val id: Long,
    val manufacturer: String,
    val material: String,
    val color: String,
    val density: Float?,
    val diameter: Float?
)