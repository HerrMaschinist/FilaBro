package com.herrmaschinist.filabro.domain.model

/**
 * Domain‑Modell für eine Filamentspule. Enthält relevante Daten aus dem Backend.
 */
data class Spool(
    val id: Long,
    val filament: Filament,
    val totalWeight: Float?,
    val emptyWeight: Float?,
    val remainingWeight: Float?,
    val name: String,
    val notes: String?
)