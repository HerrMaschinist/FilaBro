package com.herrmaschinist.filabro.presentation

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier

/**
 * Einstiegspunkt der Compose‑UI.
 * Hier wird das globale Theme gesetzt und der Navigationscontainer platziert.
 */
@Composable
fun FilaBroApp() {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            // TODO: Navigation und Inhalte einfügen
        }
    }
}