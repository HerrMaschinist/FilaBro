package com.herrmaschinist.filabro.presentation.theme

import androidx.compose.material3.Typography

// Set of Material typography styles to start with
val Typography = Typography()